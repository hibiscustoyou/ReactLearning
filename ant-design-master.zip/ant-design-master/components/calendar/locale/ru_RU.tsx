import ru_RU from '../../date-picker/locale/ru_RU';

export default ru_RU;
