import sv_SE from '../../date-picker/locale/sv_SE';

export default sv_SE;
