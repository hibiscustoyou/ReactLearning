import fr_FR from '../../date-picker/locale/fr_FR';

export default fr_FR;
