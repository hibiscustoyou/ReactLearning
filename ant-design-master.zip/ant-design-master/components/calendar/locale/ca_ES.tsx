import ca_ES from '../../date-picker/locale/ca_ES';

export default ca_ES;
