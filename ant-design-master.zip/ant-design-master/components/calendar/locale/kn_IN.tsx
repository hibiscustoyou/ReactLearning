import kn_IN from '../../date-picker/locale/kn_IN';

export default kn_IN;
