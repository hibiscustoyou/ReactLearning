import it_IT from '../../date-picker/locale/it_IT';

export default it_IT;
