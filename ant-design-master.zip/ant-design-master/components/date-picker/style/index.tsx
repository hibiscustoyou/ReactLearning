import './index.less';

// style dependencies
import '../../tag/style';
import '../../button/style';
