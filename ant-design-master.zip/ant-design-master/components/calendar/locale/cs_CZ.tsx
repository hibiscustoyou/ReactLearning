import cs_CZ from '../../date-picker/locale/cs_CZ';

export default cs_CZ;
