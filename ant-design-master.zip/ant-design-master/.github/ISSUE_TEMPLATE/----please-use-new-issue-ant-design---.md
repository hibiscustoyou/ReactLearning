---
name: '⚠️  Please use new-issue.ant.design ⚠️'
about: The issue which is not created via http://new-issue.ant.design will be closed immediately.
labels:
---

The issue which is not created via http://new-issue.ant.design will be closed immediately.

---

注意：不是用 http://new-issue.ant.design 创建的 issue 会被立即关闭。
