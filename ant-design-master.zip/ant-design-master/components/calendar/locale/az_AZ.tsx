import az_AZ from '../../date-picker/locale/az_AZ';

export default az_AZ;
